package com.cg.grocery.beans;

public class Products {
	private int productId;
	private String productName;
	private int noOfItems;
	private double costOfItem;
	private ProductType productType;
	private Customers customer;
	
	public Products(int productId, String productName, int noOfItems, double costOfItem, ProductType productType,
			Customers customer) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.noOfItems = noOfItems;
		this.costOfItem = costOfItem;
		this.productType = productType;
		this.customer = customer;
	}
	public Products() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Customers getCustomer() {
		return customer;
	}
	public void setCustomer(Customers customer) {
		this.customer = customer;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getNoOfItems() {
		return noOfItems;
	}
	public void setNoOfItems(int noOfItems) {
		this.noOfItems = noOfItems;
	}
	public double getCostOfItem() {
		return costOfItem;
	}
	public void setCostOfItem(double costOfItem) {
		this.costOfItem = costOfItem;
	}
	public ProductType getProductType() {
		return productType;
	}
	public void setProductType(ProductType productType) {
		this.productType = productType;
	}
	@Override
	public String toString() {
		return "Products [productId=" + productId + ", productName=" + productName + ", noOfItems=" + noOfItems
				+ ", costOfItem=" + costOfItem + ", productType=" + productType + ", customer=" + customer + "]";
	}
		
}
	