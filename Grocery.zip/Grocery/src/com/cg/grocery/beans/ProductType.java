package com.cg.grocery.beans;

public enum ProductType {

	GROCERIES, NON_GROCERIES;
	
}
