package com.cg.grocery.beans;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Customers {
	private int customerId;
	private String customerName;
	private CustomerType customerType;
	private LocalDate regDate;
	
	public Customers(int customerId, String customerName, CustomerType customerType, LocalDate regDate) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerType = customerType;
		this.regDate = regDate;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public CustomerType getCustomerType() {
		return customerType;
	}
	public void setCustomerType(CustomerType customerType) {
		this.customerType = customerType;
	}
	public LocalDate getRegDate() {
		return regDate;
	}
	public void setRegDate(LocalDate regDate) {
		this.regDate = regDate;
	}
	@Override
	public String toString() {
		return "Customers [customerId=" + customerId + ", customerName=" + customerName + ", customerType="
				+ customerType + ", regDate=" + regDate + "]";
	}
	
}