package com.cg.grocery.beans;

public enum CustomerType {

	EMPLOYEE, AFFILIATE, CUSTOMER;
	
}
