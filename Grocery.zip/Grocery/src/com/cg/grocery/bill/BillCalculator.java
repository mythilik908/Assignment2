package com.cg.grocery.bill;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.cg.grocery.beans.CustomerType;
import com.cg.grocery.beans.Customers;
import com.cg.grocery.beans.ProductType;
import com.cg.grocery.beans.Products;

public class BillCalculator {
	
	public static void main(String[] args) {
		
	List<Products> products = new ArrayList<>();
	
	Customers cust = new Customers(1,"Ram",CustomerType.AFFILIATE,LocalDate.parse("2015-04-10"));
	Products p = new Products(1,"Orange",5,12.0, ProductType.GROCERIES,cust);
	Customers cust1 = new Customers(2,"Shyam",CustomerType.EMPLOYEE, LocalDate.parse("2010-04-10"));
	Products p1 = new Products(2,"Cabbage",6,14.0, ProductType.GROCERIES,cust1);
	Customers cust2 = new Customers(3,"Madhu",CustomerType.CUSTOMER,LocalDate.parse("2009-12-12"));
	Products p2 = new Products(3,"Pen",3,10.0,ProductType.NON_GROCERIES,cust2);
	
	products.add(p);
	products.add(p1);
	products.add(p2);

	
	double totalCost = 0, discount=0, groceryTotal= 0, nonGroceryTotal =0;
	double commonDiscount = 0.05;
	
	for(Products prod: products)
	{
		if(prod.getProductType()== ProductType.GROCERIES)
		{
			groceryTotal = groceryTotal + prod.getCostOfItem()*prod.getNoOfItems();
			
		}
		else if(prod.getProductType() == ProductType.NON_GROCERIES)
		{
			nonGroceryTotal= nonGroceryTotal + prod.getCostOfItem()*prod.getNoOfItems();	
		}
		
    if(prod.getCustomer().getCustomerType()==CustomerType.AFFILIATE)
		{
			discount = groceryTotal * 0.01;
			totalCost = groceryTotal - discount;
	    }
	 
	else if(prod.getCustomer().getCustomerType()== CustomerType.EMPLOYEE)
		{
			discount = groceryTotal * 0.03;
			totalCost = groceryTotal -discount;
		} 
	else if(prod.getCustomer().getCustomerType() == CustomerType.CUSTOMER)
		{
			int yearDiff = LocalDate.now().getYear()-cust.getRegDate().getYear();
			if( yearDiff >= 2) {
				discount = nonGroceryTotal * 0.05;
				totalCost = groceryTotal + nonGroceryTotal - discount;
			}
			else {
				cust.setRegDate(LocalDate.now());
				totalCost = groceryTotal+ nonGroceryTotal-discount;
			}
		}
		System.out.println(totalCost- commonDiscount);
	}

}
}