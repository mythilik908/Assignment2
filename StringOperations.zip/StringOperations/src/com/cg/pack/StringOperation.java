package com.cg.pack;

import java.util.Arrays;
import java.util.Scanner;

public class StringOperation {
	
public static void primeFactors() {
	 Scanner scan = new Scanner(System.in);
	 System.out.println("Enter the number to find prime factors");
	 int number = scan.nextInt(); 
   	for(int i = 2; i< number; i++) {
        while(number % i == 0) {
           System.out.print(i+" ");
           number = number / i;
        }
     }
     if(number >2) {
        System.out.println(number);
     }
}
public static void  AlphabetSoup()
{
	 Scanner scan = new Scanner(System.in);
	 System.out.println("Enter the string to sort");
	 String str = scan.nextLine();
	 
	String k = str.toString();
	char[] charArray = k.toCharArray();
	Arrays.sort(charArray);
	String sortedString = new String(charArray);
	System.out.println(sortedString);  
}

public static void LetterChanges()
{
	StringBuffer sbuffer = new StringBuffer();
	Scanner input = new Scanner(System.in);
	System.out.println("Enter the sentence to Letter Change");
	StringBuffer m = new StringBuffer();
	sbuffer.append(input.nextLine());
	
	int len = sbuffer.length();
	for(int i=0;i< len;i++){
	m.append((char)(sbuffer.charAt(i)+1));
	}
	System.out.println(m.toString().replaceAll("!", " "));
	}


public static void LetterCapitalize()
{
	 Scanner scan = new Scanner(System.in);
	 System.out.println("Enter the sentence to capitalize");
	 String string1 = scan.nextLine();
	 StringBuffer res = new StringBuffer();
	 String[] strArr = string1.split(" ");
     for (String str : strArr) {
        char[] stringArray = str.trim().toCharArray();
        stringArray[0] = Character.toUpperCase(stringArray[0]);
        str = new String(stringArray);
        res.append(str).append(" ");
    }
    System.out.println(res.toString().trim());
}


public static void  ReverseOrder()
{ 
	 Scanner scan = new Scanner(System.in);
	 System.out.println("Enter the string to be reversed");
	 String string1 = scan.nextLine();
	
	String rev="";
	for(int j=string1.length();j>0;--j)
	{
	rev=rev+(string1.charAt(j-1)); 
	}
	System.out.println(rev);

}

public static void FirstFactorial(){
	 Scanner scan = new Scanner(System.in);
	 System.out.println("Enter the number to find factorial");
	 int number = scan.nextInt(); 
	int fact = 1;
	for(int i=1;i<=number;i++){    
	      fact=fact*i;    
	  }    
	  System.out.println("Factorial is "+fact); 
}

public static void LongestWord()
{
	 Scanner scan = new Scanner(System.in);
	 System.out.println("Enter the setence");
	 String string1 = scan.nextLine();
	 
	 String[] word = string1.split( " " );
     String rts = " ";
     int index = 0;

     for ( int i = 0; i < word.length; i++ )
     {
         if ( word[i].length() > rts.length() )
             rts = word[i];

     }
     System.out.println( rts.length() );
}

public static void AnagramChecker() {
	Scanner scan = new Scanner(System.in);
	System.out.println("Enter the two strings to check");
	String string1 = scan.nextLine();
    String string2 = scan.nextLine();
	char[] charArray = string1.toCharArray();
	char[] charArray1 = string2.toCharArray();

	Arrays.sort(charArray);
	Arrays.sort(charArray1);

	System.out.println(charArray.equals(charArray1));
	
}
public static void main(String[] args) {
Scanner scan = new Scanner(System.in);

while(true) {
	System.out.println("Choose the operation to perform");
	System.out.println("1. Anagram Checker");
	System.out.println("2. To find longest word in sentence");
	System.out.println("3. To find prime factors of a number");
	System.out.println("4. To find alphabet soup");
	System.out.println("5. To Capitalize the starting letter of word");
	System.out.println("6. Letter Changes");
	System.out.println("7. To reverse a string");
	System.out.println("8. To find factorial of a number");
String choice = scan.next();
switch(choice) {

case "1" :
     AnagramChecker();
     break;
case "2" :    
     LongestWord();
     break;
case "3": 
     primeFactors();
     break;
case "4": 
	 AlphabetSoup();
	 break;
case "5" :
	 LetterCapitalize();
	 break;
case "6" :
	 LetterChanges();
	 break;
case "7":
     ReverseOrder();
     break;
case "8" :
     FirstFactorial();
     break;
case "9":
	System.exit(0);
default :
	System.out.println("Enter correct choice");
	break;
}
}
}
}




